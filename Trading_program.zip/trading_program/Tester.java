package mac286.Project;

import java.util.Vector;

public class Tester {

		public static void main(String[] args) {
			//create a symbol tester
			Vector<Trade> Trades = new Vector<Trade>(3000);
			float riskfactor = 2;
			String symbol = "AAPL";
			SymbolTester tester = new SymbolTester(symbol,"/Users/luismora/eclipse-workspace/mac286/Data/" , riskfactor);
			tester.test();
			Trades.addAll(tester.getTrades());
			for(int i = 0; i <Trades.size(); i++) {
				System.out.println(Trades.elementAt(i).toString());
			}
			
			
			
			
		}
}
