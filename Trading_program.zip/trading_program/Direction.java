package mac286.Project;

public enum Direction {
	LONG, SHORT, NONE;
}
