package mac286.Project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

public class SymbolTester {
	private float riskFactor;
	private String symbol;
	private String dataPath;
	
	private Vector<Bar> mData;
	private Vector<Trade> mTrades;
	private boolean Dataload = false;
	
	//constructor
	SymbolTester(String s, String p, float risk) {
		riskFactor = risk;
		symbol = s;
		dataPath = p;
		mData = new Vector<Bar>(3000);
		mTrades = new Vector<Trade>(200);
	}
	//The only getter for the trade, the others you receive
public Vector<Trade> getTrades(){
		return mTrades;
	}
	//load the data
public void loadData() {
		//create file name
		String fileName = dataPath + symbol + "_Daily.csv";
		try {
		FileReader fr = new FileReader(fileName);
		BufferedReader br = new BufferedReader(fr);
		String line = br.readLine();
		while((line = br.readLine()) != null) {
			//create a bar using the constructor that accepts line
			Bar b = new Bar(line);
			//add the bar to the vector
			mData.add(b);
		}
		Dataload = true;
		br.close();
		fr.close();
		}catch(IOException e){
			System.out.println("Error: " + e.getMessage()); 
			Dataload = false;
			return;
		}
	}
	//this is to make sure that each bar is lower than the previous
	private boolean XDaysLow(int ind, int days) {
		for(int i = ind-1; i > ind-days; i--) {
			if(mData.elementAt(i).getLow() < mData.elementAt(ind).getLow())
				return false;
		}
		return true;
	}
	private boolean XDaysHigh(int ind, int days) {
		for(int i = ind-1; i > ind-days; i--) {
			if(mData.elementAt(i).getHigh() > mData.elementAt(ind).getHigh())
				return false;
		}
		return true;
	}
	void outcomes(Trade T, int ind) {
		for(int i = ind; i < mData.size(); i++) {
			if(T.getDir() == Direction.LONG) { //if todays high is higher than the target ,then we won
				if(mData.elementAt(i).getHigh() > T.getTarget()) {
					//consider a gap day, 
					if(mData.elementAt(i).getOpen() > T.getTarget()) { 
						//close at open a gap day
						T.close(mData.elementAt(i).getDate(), mData.elementAt(i).getOpen(), i-ind);
						return;
					} else {
						//close the trade at target
						T.close(mData.elementAt(i).getDate(), T.getTarget(), i-ind);// number of days you stayed in the trade
						return;
					}
					//if the todays low is lower than stop loss, then its a lost
				} else if(mData.elementAt(i).getLow() < T.getStopLoss()) {
					//check if there is a gap down
					if(mData.elementAt(i).getOpen() < T.getStopLoss()) {
						//get out at open
						T.close(mData.elementAt(i).getDate(), mData.elementAt(i).getOpen(), i-ind);
						return;
					} else {
						//get out of stop loss
						T.close(mData.elementAt(i).getDate(), T.getStopLoss(), i-ind);
						return;
					}
				}
			}else { 
				//short trade
				if(mData.elementAt(i).getLow() <= T.getTarget()) { //this is for the win
					//a gap day
					if(mData.elementAt(i).getOpen() < T.getTarget()) {
						//close at gap day
						T.close(mData.elementAt(i).getDate(), mData.elementAt(i).getOpen(), i-ind);
						return;
					} else {
						//close trade at target
						T.close(mData.elementAt(i).getDate(), T.getTarget(), i-ind);
						return;
						}
					} else if(mData.elementAt(i).getHigh() >= T.getStopLoss()){
						//gap down
						if(mData.elementAt(i).getOpen() > T.getStopLoss()) {
							//close at open
							T.close(mData.elementAt(i).getDate(), mData.elementAt(i).getOpen(), i-ind);
							return;
						} else {
							//out of stop loss
							T.close(mData.elementAt(i).getDate(), T.getStopLoss(), i-ind);
							return;
						}
					}
				}
			}
		 // end of for loop
		//if we get here the trade is not closed, close it at the close of the last day
		T.close(mData.elementAt(mData.size()-1).getDate(), mData.elementAt(mData.size()-1).getClose(), mData.size()-1-ind);
	} 
	public boolean test() {
		if(!Dataload) { //if data load is not false, loadData()
			loadData();
			if (!Dataload) {
				System.out.println("Data Not Loaded");
				return false;
			}
		} 
		
		//display
		//Today(i) makes 20 days low
		for(int i = 20; i < mData.size()-1; i++) { // Long Trade
			if(XDaysLow(i,20) 
					&& mData.elementAt(i).getOpen() < mData.elementAt(i-1).getLow() //today open lower than low of previous
					&& mData.elementAt(i).getClose() > mData.elementAt(i-1).getClose() //today close higher than previous day
					&& mData.elementAt(i-1).getClose() < mData.elementAt(i-1).getOpen())  //yesterday close lower than yesterday open
			{
				//we have a trade, buy next day at open, stop loss at todays low
				float entryprice = mData.elementAt(i+1).getOpen();
				float stoploss = mData.elementAt(i).getLow() - 0.01f; //0.01 to get past the low
				float risk = entryprice - stoploss;
				float target = entryprice + riskFactor * risk;
				Trade T = new Trade();
				T.open(symbol, mData.elementAt(i+1).getDate(), entryprice, stoploss, target, Direction.LONG);
				outcomes(T, i+1);
				mTrades.add(T);
			} else if(XDaysHigh(i, 20) //short Trade
					&& mData.elementAt(i).getOpen() > mData.elementAt(i-1).getHigh() 
					&& mData.elementAt(i).getClose() < mData.elementAt(i-1).getClose()
					&& mData.elementAt(i-1).getClose() > mData.elementAt(i-1).getOpen()) {
				//we have a trade, buy next day at open, stop loss at todays high
				float entryprice = mData.elementAt(i+1).getOpen(); 
				float stoploss = mData.elementAt(i).getHigh() + 0.01f;
				float risk = stoploss - entryprice;
				float target = entryprice - riskFactor * risk;
				Trade T = new Trade();
				T.open(symbol, mData.elementAt(i+1).getDate(), entryprice, stoploss, target, Direction.SHORT);
				outcomes(T, i+1);
				//add the trade to the Trade vector
				mTrades.add(T);
			}
				
			
		}
		//for(int i = 0; i < 10; i++) {
		 //System.out.println(mData.elementAt(i).toString());
		//}
		
		return true;
	}
	
	
}
